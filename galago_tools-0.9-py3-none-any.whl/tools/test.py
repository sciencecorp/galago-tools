from tools.toolbox.db import Db

Db.check_connection()
Db.ping(5)